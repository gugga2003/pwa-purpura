"use client";

import Link from "next/link";

export default function ActivationPage() {
  return (
    <div className="bg-background-light dark:bg-background-dark min-h-screen">
      <div className="relative mx-auto flex h-full min-h-screen max-w-[480px] flex-col overflow-x-hidden">
        <header className="sticky top-0 z-10 flex items-center bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md px-4 py-4 justify-between">
          <Link
            href="/"
            className="text-[#171216] dark:text-white flex size-10 shrink-0 items-center justify-center rounded-full hover:bg-black/5 dark:hover:bg-white/5 cursor-pointer"
          >
            <span className="material-symbols-outlined">arrow_back_ios_new</span>
          </Link>
          <h2 className="text-[#171216] dark:text-white text-lg font-bold leading-tight tracking-tight flex-1 text-center pr-10">
            Activaci�n de Cuenta
          </h2>
        </header>
        <main className="flex-1 px-5 pt-4 pb-10">
          <div className="mb-8">
            <div className="mb-4 inline-flex items-center justify-center p-3 bg-primary/10 rounded-xl">
              <span className="material-symbols-outlined text-primary text-3xl">verified_user</span>
            </div>
            <h1 className="text-[#171216] dark:text-white tracking-tight text-3xl font-extrabold leading-tight mb-2">
              �Bienvenido a <span className="text-primary">La P�rpura</span>!
            </h1>
            <p className="text-[#4b3d49] dark:text-gray-400 text-base font-medium leading-relaxed">
              Est�s activando tu perfil como <span className="text-[#171216] dark:text-white font-bold">Referente</span> para el
              territorio: <span className="text-primary font-bold italic">Valle del Cauca</span>
            </p>
          </div>
          <div className="space-y-6">
            <div className="flex flex-col gap-2">
              <label className="text-[#171216] dark:text-gray-200 text-sm font-semibold uppercase tracking-wider ml-1">
                Nueva contrase�a
              </label>
              <div className="relative group">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-gray-400 group-focus-within:text-primary transition-colors">
                  <span className="material-symbols-outlined text-[20px]">lock</span>
                </div>
                <input
                  className="block w-full pl-11 pr-12 h-14 bg-white dark:bg-surface-dark border-2 border-[#e4dce3] dark:border-gray-700 rounded-xl focus:ring-0 focus:border-primary transition-all text-[#171216] dark:text-white placeholder:text-[#85667f]/50"
                  placeholder="M�nimo 8 caracteres"
                  type="password"
                />
                <button className="absolute inset-y-0 right-0 pr-4 flex items-center text-[#85667f] dark:text-gray-400">
                  <span className="material-symbols-outlined">visibility</span>
                </button>
              </div>
              <div className="mt-2 flex flex-wrap gap-x-4 gap-y-2 px-1">
                <div className="flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[16px] text-green-500">check_circle</span>
                  <span className="text-xs text-gray-600 dark:text-gray-400">8+ caracteres</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[16px] text-gray-300">circle</span>
                  <span className="text-xs text-gray-600 dark:text-gray-400">1 n�mero</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[16px] text-gray-300">circle</span>
                  <span className="text-xs text-gray-600 dark:text-gray-400">1 s�mbolo</span>
                </div>
              </div>
            </div>
            <div className="flex flex-col gap-2">
              <label className="text-[#171216] dark:text-gray-200 text-sm font-semibold uppercase tracking-wider ml-1">
                Confirmar contrase�a
              </label>
              <div className="relative group">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-gray-400 group-focus-within:text-primary transition-colors">
                  <span className="material-symbols-outlined text-[20px]">lock_reset</span>
                </div>
                <input
                  className="block w-full pl-11 pr-12 h-14 bg-white dark:bg-surface-dark border-2 border-[#e4dce3] dark:border-gray-700 rounded-xl focus:ring-0 focus:border-primary transition-all text-[#171216] dark:text-white placeholder:text-[#85667f]/50"
                  placeholder="Repite tu contrase�a"
                  type="password"
                />
                <button className="absolute inset-y-0 right-0 pr-4 flex items-center text-[#85667f] dark:text-gray-400">
                  <span className="material-symbols-outlined">visibility</span>
                </button>
              </div>
            </div>
            <div className="pt-2">
              <label className="relative flex items-start gap-3 cursor-pointer group">
                <div className="relative flex items-center pt-0.5">
                  <input className="peer sr-only" type="checkbox" />
                  <div className="size-6 bg-white dark:bg-surface-dark border-2 border-[#e4dce3] dark:border-gray-700 rounded-lg peer-checked:bg-primary peer-checked:border-primary transition-all"></div>
                  <span className="material-symbols-outlined absolute text-white opacity-0 peer-checked:opacity-100 left-0 right-0 text-center text-[18px] font-bold">
                    check
                  </span>
                </div>
                <span className="text-[#4b3d49] dark:text-gray-300 text-sm leading-snug">
                  He le�do y acepto los{" "}
                  <a className="text-primary font-bold underline decoration-primary/30" href="#">
                    T�rminos de Uso
                  </a>{" "}
                  y la{" "}
                  <a className="text-primary font-bold underline decoration-primary/30" href="#">
                    Pol�tica de Privacidad Institucional
                  </a>.
                </span>
              </label>
            </div>
            <div className="pt-6">
              <button className="w-full h-16 bg-[#851c74] hover:bg-primary text-white text-lg font-bold rounded-2xl shadow-lg shadow-primary/20 active:scale-[0.98] transition-all flex items-center justify-center gap-2">
                <span>Activar Mi Cuenta</span>
                <span className="material-symbols-outlined">arrow_forward</span>
              </button>
            </div>
            <div className="text-center pt-4">
              <p className="text-gray-500 dark:text-gray-500 text-xs">
                Si tienes problemas con la activaci�n, contacta a tu coordinador territorial.
              </p>
            </div>
          </div>
        </main>
        <div className="mt-auto px-6 pb-8">
          <div className="w-full h-1.5 bg-gray-200 dark:bg-gray-800 rounded-full overflow-hidden">
            <div className="w-1/3 h-full bg-primary rounded-full"></div>
          </div>
          <div className="mt-4 flex justify-center">
            <div className="w-32 h-1 bg-[#171216] dark:bg-white rounded-full opacity-20"></div>
          </div>
        </div>
      </div>
    </div>
  );
}
